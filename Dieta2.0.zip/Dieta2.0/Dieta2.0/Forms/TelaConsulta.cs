﻿using Dieta2._0.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dieta2._0.Forms
{

    public partial class TelaConsulta : Form
    {
        List<tblPaciente> listaPacientes;
        double imc;
        tblNutricionista nutricionistaLogado;

        public void LimparTela()
        {
            foreach (var item in this.Controls)
            {
                if (item is TextBox)
                {
                    ((TextBox)item).Text = "";
                }
                if (item is ComboBox)
                {
                    ((ComboBox)item).SelectedIndex = -1;
                }
                if (item is RichTextBox)
                {
                    ((RichTextBox)item).Text = "";
                }
            }
        }

        public TelaConsulta(tblNutricionista nutricionista)
        {
            InitializeComponent();
            this.nutricionistaLogado = nutricionista;
            labelNutricionista.Text = "Nutricionista: " + nutricionistaLogado.Nome;
            this.CarregarPacientes();
            labelData.Text = "Data: " + DateTime.Now.ToShortDateString();
        }
        private void CarregarPacientes()
        {
            DadosPaciente dados = new DadosPaciente();
            tblPaciente filtro = new tblPaciente();
            this.listaPacientes = dados.ListarPacientes(filtro);
            comboBoxPacientes.Items.Clear();
            foreach (tblPaciente item in this.listaPacientes)
            {
                comboBoxPacientes.Items.Add(item.NOME);
            }
        }

        private void BtnSalvar_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (comboBoxPacientes.SelectedIndex < 0)
                {
                    MessageBox.Show("Selecionar o paciente");
                    comboBoxPacientes.Focus();
                    return;
                }
                this.CalcularImc();
                Dieta dieta = new Dieta();
                CONSULTA consulta = new CONSULTA();
                tblNutricionista nutricionista = new tblNutricionista();


                labelData.Text = DateTime.Now.ToShortDateString();
                

                consulta.PESO = Convert.ToInt32(txtPeso.Text);
                consulta.ALTURA = Convert.ToDecimal(txtAltura.Text);
                consulta.IMC = Convert.ToDecimal(txtIMC.Text);
                consulta.ID_NUTRI_CONSULTA = this.nutricionistaLogado.Id_Nutri;
   
                tblPaciente pacEscolhido = listaPacientes.ElementAt(comboBoxPacientes.SelectedIndex);

                consulta.ID_PACIENTE_CONSULTA = pacEscolhido.ID_PACIENTE;

                dieta.CONSULTA.Add(consulta);
                dieta.SaveChanges();

                MessageBox.Show("Cadastro concluído com sucesso!");
                this.LimparTela();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        public void CalcularImc()
        {
            double peso;
            double altura;

            Double.TryParse(txtPeso.Text, out peso);
            Double.TryParse(txtAltura.Text, out altura);


            if (altura != 0)
            {
                imc = peso / (altura * altura);

            }
            else
            {
                imc = 0;
            }

            if (imc <= 18.4)
            {
                txtResultadoImc.Text = "Abaixo do peso ideal";
            }
            if (imc >= 18.5 && imc <= 24.99)
            {
                txtResultadoImc.Text = "Peso ideal";
            }
            if (imc >= 25 && imc <= 29.9)
            {
                txtResultadoImc.Text = "Sobrepeso";
            }
            if (imc >= 30 && imc <= 34.9)
            {
                txtResultadoImc.Text = "Obesidade grau 1";
            }
            if (imc >= 35 && imc <= 39.9)
            {
                txtResultadoImc.Text = "Obesidade grau 2";
            }
            else
            {
                txtResultadoImc.Text = "Obesidade mórbida";
            }

            txtIMC.Text = imc.ToString();
        }



        private void ButtonCalcularImc_Click(object sender, EventArgs e)
        {
            this.CalcularImc();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            CadastrarPaciente cadastrar = new CadastrarPaciente(nutricionistaLogado);
            cadastrar.Show();
            this.Close();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            TelaConsulta tela = new TelaConsulta(nutricionistaLogado);
            tela.Show();
            this.Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            ConsultarHistorico consultar = new ConsultarHistorico(nutricionistaLogado);
            consultar.Show();
            this.Close();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }
    }
}
