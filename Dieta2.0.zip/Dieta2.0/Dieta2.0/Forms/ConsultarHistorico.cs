﻿using Dieta2._0.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dieta2._0.Forms
{
    public partial class ConsultarHistorico : Form
    {
        tblNutricionista nutrilogado;

        public ConsultarHistorico(tblNutricionista nutricionista)
        {
            InitializeComponent();
        }

        private void VoltarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ConsultarHistorico_Load(object sender, EventArgs e)
        {
            Dieta bd = new Dieta();
            foreach (CONSULTA consulta in bd.CONSULTA)
            {
                ListViewItem item = listView1.Items.Add(consulta.tblPaciente.NOME);
                item.SubItems.Add(consulta.DATACONSULTA.ToString());
                item.SubItems.Add(consulta.IDADE.ToString());
                item.SubItems.Add(consulta.tblPaciente.CPF);
                item.SubItems.Add(consulta.IMC.ToString());
                item.SubItems.Add(consulta.PESO.ToString());
                item.SubItems.Add(consulta.ALTURA.ToString());
                item.SubItems.Add(consulta.OBSERVACOES);
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                Dieta bd = new Dieta();
                DadosConsulta dados = new DadosConsulta();
                CONSULTA c = bd.CONSULTA.ToList().ElementAt(listView1.FocusedItem.Index);
                dados.ApagarConsulta(c);
                ConsultarHistorico_Load(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }   
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            CadastrarPaciente cadastrar = new CadastrarPaciente(nutrilogado);
            cadastrar.Show();
            this.Hide();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            TelaConsulta tela = new TelaConsulta(nutrilogado);
            tela.Show();
            this.Hide();
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            ConsultarHistorico historico = new ConsultarHistorico(nutrilogado);
            historico.Show();
            this.Hide();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            
        }
    }

