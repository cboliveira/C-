﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieta2._0.DAO
{
    public class DadosNutricionista
    {
        public tblNutricionista Logar(string nome, string senha)
        {
            var contexto = new Dieta();

            try
            {
                var x = contexto.tblNutricionista.Where(n => n.Nome == nome && n.Senha == senha);
                return x.FirstOrDefault();
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void CadastrarNutricionista(tblNutricionista nutri)
        {
            Dieta dietaEntities = new Dieta();
            dietaEntities.tblNutricionista.Add(nutri);
            dietaEntities.SaveChanges();
            dietaEntities.Dispose();
        }

        public List<tblNutricionista> ListarNutricionista(tblNutricionista nutri)
        {
            Dieta entities = new Dieta();
            List<tblNutricionista> retorno = entities.tblNutricionista.ToList();
            entities.Dispose();
            return retorno;
        }

        public void ApagarNutricionista(tblNutricionista nutricionista)
        {
            using (var context = new Dieta())
            {
                try
                {
                    context.tblNutricionista.Remove(nutricionista);
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}