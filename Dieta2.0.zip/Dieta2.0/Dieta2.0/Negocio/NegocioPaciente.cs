﻿using Dieta2._0.DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieta2._0.Negocio
{
    class NegocioPaciente
    {
        public void CadastrarPaciente(tblPaciente paciente)
        {

            if (string.IsNullOrEmpty(paciente.NOME) == true)
            {
                throw new Exception("Informar o nome do paciente");
            }

            if (string.IsNullOrEmpty(paciente.TELEFONE) == true)
            {
                throw new Exception("Informar o telefone do paciente");
            }

            if (paciente.NOME.Length > 100)
            {
                throw new Exception("O nome informado ultrapassou o limite de 100 caracteres suportados!");
            }

            if (paciente.TELEFONE.Length > 11)
            {
                throw new Exception("O numero do telefone informado ultrapassou 11 digitos!");
            }

            if (paciente.TELEFONE.Length < 11)
            {
                throw new Exception("O numero do telefone informado devera conter 11 digitos!");
            }

            DadosPaciente d = new DadosPaciente();
            d.CadastrarPaciente(paciente);

        }
    }
}
