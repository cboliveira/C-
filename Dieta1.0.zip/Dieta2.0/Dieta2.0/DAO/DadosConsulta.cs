﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieta2._0.DAO
{
    public class DadosConsulta
    {
        public void CadastrarConsulta(CONSULTA consulta)
        {
            Dieta bd = new Dieta();
            bd.CONSULTA.Add(consulta);
            bd.SaveChanges();
            bd.Dispose();
        }

        public List<CONSULTA> ListarConsultas(CONSULTA consulta)
        {
            Dieta dieta = new Dieta();
            List<CONSULTA> retorno = dieta.CONSULTA.ToList();
            dieta.Dispose();
            return retorno;
        }
        public void AtualizarConsulta(CONSULTA consulta)
        {
            using (var context = new Dieta())
            {
                try
                {
                    CONSULTA cons = context.CONSULTA.SingleOrDefault(c => c.ID_CONSULTA == consulta.ID_CONSULTA);
                    cons.ALTURA = consulta.ALTURA;
                    cons.DATACONSULTA = consulta.DATACONSULTA;
                    cons.HORAFIM = consulta.HORAFIM;
                    cons.HORAINICIO = consulta.HORAINICIO;
                    cons.IDADE = consulta.IDADE;
                    cons.PESO = consulta.PESO;
                    cons.IMC = consulta.IMC;
                    cons.OBSERVACOES = consulta.OBSERVACOES;
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
        }

        public void ApagarConsulta(CONSULTA consulta)
        {
            using (var context = new Dieta())
            {
                CONSULTA c = context.CONSULTA.Find(consulta.ID_CONSULTA);

                context.CONSULTA.Remove(c);
                context.SaveChanges();

            }

        }

    }
}
