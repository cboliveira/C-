﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieta2._0.DAO
{
   public class DadosPaciente
    {
        public void CadastrarPaciente(tblPaciente paciente)
        {
            Dieta bd = new Dieta();
            bd.tblPaciente.Add(paciente);
            bd.SaveChanges();
            bd.Dispose();

        }
        public List<tblPaciente> ListarPacientes(tblPaciente filtro)
        {
            Dieta bd = new Dieta();
            List<tblPaciente>  retorno = bd.tblPaciente.ToList();
            bd.Dispose();
            return retorno;
        }
        public void AtualizarPaciente(tblPaciente paciente)
        {
            using (var context = new Dieta())
            {
                try
                {
                    tblPaciente paci = context.tblPaciente.SingleOrDefault(p => p.ID_PACIENTE == paciente.ID_PACIENTE);
                    paci.NOME = paciente.NOME;
                    paci.IDADE = paciente.IDADE;
                    paci.TELEFONE = paciente.TELEFONE;
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
               
            }
        }
        public void ApagarPaciente(tblPaciente paciente)
        {
            using (var context = new Dieta())
            {
                try
                {
                    context.tblPaciente.Remove(paciente);
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

    }
}
