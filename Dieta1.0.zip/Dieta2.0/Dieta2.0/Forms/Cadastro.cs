﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dieta2._0.Forms
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Dieta cadastro = new Dieta();
            tblNutricionista nutri = new tblNutricionista();

            nutri.Nome = textBoxCadastroNomeNutri.Text;
            nutri.Crn = textBoxCadastroCrn.Text;
            nutri.Senha = textBoxCadastroSenha.Text;

            if(txtConfirmarSenha != textBoxCadastroSenha)
            {
                MessageBox.Show("Senhas não coincidem!");
            }

            cadastro.tblNutricionista.Add(nutri);
            cadastro.SaveChanges();

            MessageBox.Show("Cadastro concluído com sucesso!");


            Login login = new Login();
            login.Show();

            this.Close();
        }

        private void VoltarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();

            this.Close();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            Cadastro cadastro = new Cadastro();
            cadastro.Show();
            this.Close();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
