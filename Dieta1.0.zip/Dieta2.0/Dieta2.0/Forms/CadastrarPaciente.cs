﻿using Dieta2._0.Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dieta2._0.Forms
{
    public partial class CadastrarPaciente : Form
    {
        tblNutricionista nutricionistaLogado;

        public CadastrarPaciente(tblNutricionista nutricionista)
        {
            InitializeComponent();
            this.nutricionistaLogado = nutricionista;
        }


        private void VoltarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ButtonCadastrarPaciente_Click(object sender, EventArgs e)
        {
            try
            {
                tblPaciente paciente = new tblPaciente();
                NegocioPaciente negocioPaciente = new NegocioPaciente();

                paciente.NOME = textBoxCadastrarNomePaciente.Text;
                paciente.TELEFONE = textBoxCadastrarTelefonePaciente.Text;
                paciente.CPF = textBoxCadastrarCpfPaciente.Text;
                paciente.IDADE = Convert.ToInt32(textBoxCadastrarIdadePaciente.Text);
                paciente.ID_NUTRI_PACIENTE = this.nutricionistaLogado.Id_Nutri;

                negocioPaciente.CadastrarPaciente(paciente);

                MessageBox.Show("Cadastro concluído com sucesso!");

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            CadastrarPaciente cadastrar = new CadastrarPaciente(nutricionistaLogado);
            cadastrar.Show();
            this.Close();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            TelaConsulta tela = new TelaConsulta(nutricionistaLogado);
            tela.Show();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            ConsultarHistorico consultar = new ConsultarHistorico(nutricionistaLogado);
            consultar.Show();
            this.Close();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }
    }
}
