﻿using Dieta2._0.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dieta2._0.DAO;

namespace Dieta2._0
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

            if ((textBoxLoginNome.Text == "") || (textBoxLoginSenha.Text == ""))
            {
                MessageBox.Show("Informe nome de usuário e senha!");
                textBoxLoginNome.Focus();
                return;
            }

            DadosNutricionista dao = new DadosNutricionista();
            tblNutricionista nutri = dao.Logar(textBoxLoginNome.Text, textBoxLoginSenha.Text);

            if (nutri != null)
            {
                TelaConsulta tela = new TelaConsulta(nutri);
                tela.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuário e senha incorretos!");
                textBoxLoginNome.Focus();
            }


        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Cadastro cadastro = new Cadastro();
            cadastro.Show();
            this.Hide();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            Cadastro cadastro = new Cadastro();
            cadastro.Show();
            this.Hide();
        }
    }
}
