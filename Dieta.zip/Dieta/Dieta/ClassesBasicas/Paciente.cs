﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieta.ClassesBasicas
{
    [Table("tblPaciente")]
    public class Paciente
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Paciente()
        {
            Consultas = new HashSet<Consulta>();
        }

        [Key]
        public int ID_PACIENTE { get; set; }
        public int ID_NUTRI_PACIENTE { get; set; }
        [Required]
        [StringLength(100)]
        public string NOME { get; set; }
        [Required]
        [StringLength(11)]
        public string TELEFONE { get; set; }

        [ForeignKey("ID_NUTRI_PACIENTE")]
        public virtual Nutricionista Nutricionista { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Consulta> Consultas { get; set; }
    }
}
