﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieta.ClassesBasicas
{
    [Table("CONSULTA")]
    public class Consulta
    {
        [Key]
        public int ID_CONSULTA { get; set; }

        public int ID_NUTRI_CONSULTA { get; set; }

        public int ID_PACIENTE_CONSULTA { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DATACONSULTA { get; set; }

        public DateTime? HORAINICIO { get; set; }

        public DateTime? HORAFIM { get; set; }

        public decimal PESO { get; set; }

        public decimal ALTURA { get; set; }

        public int IDADE { get; set; }

        public decimal IMC { get; set; }

        public string OBSERVACOES { get; set; }

        [ForeignKey("ID_NUTRI_CONSULTA")]
        public virtual Nutricionista Nutricionista { get; set; }

        [ForeignKey("ID_PACIENTE_CONSULTA")]
        public virtual Paciente Paciente { get; set; }
    }
}
