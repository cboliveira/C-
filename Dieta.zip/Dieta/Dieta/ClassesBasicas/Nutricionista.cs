﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieta.ClassesBasicas
{
    [Table("tblNutricionista")]
    public class Nutricionista
    {
       [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Nutricionista()
        {
            Consultas = new HashSet<Consulta>();
            Pacientes = new HashSet<Paciente>();
        }

        [Key]
        public int Id_Nutri { get; set; }

        [Required]
        [StringLength(20)]
        public string Crn { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; }

        [Required]
        [StringLength(12)]
        public string senha { get; set; }

        public virtual ICollection<Paciente> Pacientes { get; set; }
        public virtual ICollection<Consulta> Consultas { get; set; }
    }
}
