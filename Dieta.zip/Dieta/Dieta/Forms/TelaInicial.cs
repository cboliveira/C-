﻿using Dieta.ClassesBasicas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dieta.Forms
{
    public partial class TelaInicial : Form
    {
        Nutricionista nutricionistaLogado;

        public TelaInicial()
        {
            InitializeComponent();
        }

        public TelaInicial(Form login, Nutricionista nutr)
        {
            InitializeComponent();
            
            this.nutricionistaLogado = nutr;
            MessageBox.Show(nutr.Id_Nutri.ToString());
            login.Hide();// Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            CadastrarPaciente cadastrar = new CadastrarPaciente();
            cadastrar.Show();
            this.Close();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void TelaInicial_Load(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            TelaConsulta tela = new TelaConsulta();
            tela.Show();

        }

        private void Button3_Click(object sender, EventArgs e)
        {

            this.Close();
        }
    }
}
