﻿using Dieta.ClassesBasicas;
using Dieta.DAO;
using Dieta.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dieta
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void ProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Cadastro cadastro = new Cadastro();
            cadastro.Show();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if ((textBoxLoginNome.Text == "") || (textBoxLoginSenha.Text == ""))
            {
                MessageBox.Show("Informe nome de usuário e senha!");
                textBoxLoginNome.Focus();
            }

            NutricionistaDAO dao1 = new NutricionistaDAO();
            NutricionistaDAO2 dao2 = new NutricionistaDAO2();
            Nutricionista nutri = dao2.Logar(textBoxLoginNome.Text, textBoxLoginSenha.Text);

            if (nutri != null)
            {
                TelaInicial tela = new TelaInicial(this,nutri);
                tela.ShowDialog();
            }
            else {
                MessageBox.Show("Usuário e senha incorretos!");
                textBoxLoginNome.Focus();
            }
        }
    }
}