﻿using Dieta.ClassesBasicas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dieta.Forms
{
    public partial class CadastrarPaciente : Form
    {
        public CadastrarPaciente()
        {
            InitializeComponent();
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void CadastrarPaciente_Load(object sender, EventArgs e)
        {

        }

        private void VoltarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaInicial telaInicial = new TelaInicial();
            telaInicial.Show();
            this.Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Contexto dieta = new Contexto();
            Paciente paciente = new Paciente();

            paciente.NOME = textBoxCadastrarNomePaciente.Text;
            paciente.TELEFONE = textBoxCadastrarTelefonePaciente.Text;
            paciente.ID_NUTRI_PACIENTE = 1;
            dieta.Pacientes.Add(paciente);
            dieta.SaveChanges();

            MessageBox.Show("Cadastro concluído com sucesso!");

            TelaInicial telaInicial = new TelaInicial();
            telaInicial.Show();
            this.Close();
        }
    }
}
