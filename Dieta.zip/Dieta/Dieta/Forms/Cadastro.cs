﻿using Dieta.ClassesBasicas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dieta
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {
            InitializeComponent();
        }

        private void Cadastro_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Contexto cadastro = new Contexto();
            Nutricionista nutri = new Nutricionista();

            nutri.Nome = textBoxCadastroNomeNutri.Text;
            nutri.Crn = textBoxCadastroCrn.Text;
            nutri.senha = textBoxCadastroSenha.Text;

            cadastro.Nutricionistas.Add(nutri);
            cadastro.SaveChanges();

            MessageBox.Show("Cadastro concluído com sucesso!");


            Login login = new Login();
            login.Show();

            this.Close();


        }

        private void VoltarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();

            this.Close();
        }
    }
}
