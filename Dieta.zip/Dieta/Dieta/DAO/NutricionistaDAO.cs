﻿using Dieta.ClassesBasicas;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieta.DAO
{
    public class NutricionistaDAO
    {
        string connectionString = ConfigurationManager.ConnectionStrings["DietaEntities"].ConnectionString;

        public void Gravar(Nutricionista nutri)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                try {
                    cn.Open();

                    StringBuilder sb = new StringBuilder();
                    sb.Append("INSERT INTO tblNutricionista (id_nutri, crn, nome, senha)");
                    sb.Append("VALUES (@id_nutri, @crn, @nome, @senha)");

                    SqlCommand cmd = new SqlCommand(sb.ToString(), cn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@id_nutri", nutri.Id_Nutri);
                    cmd.Parameters.AddWithValue("@crn", nutri.Crn);
                    cmd.Parameters.AddWithValue("@nome", nutri.Nome);
                    cmd.Parameters.AddWithValue("@senha", nutri.senha);

                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    cn.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public void Atualizar(Nutricionista nutri)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                try
                {
                    cn.Open();

                    StringBuilder sb = new StringBuilder();
                    sb.Append("UPDATE tblNutricionista      ");
                    sb.Append("   SET crn   = @crn,         ");
                    sb.Append("       nome  = @nome,        ");
                    sb.Append("       senha = @senha        ");
                    sb.Append(" WHERE id_nutri = @id_nutri  ");

                    SqlCommand cmd = new SqlCommand(sb.ToString(), cn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@id_nutri", nutri.Id_Nutri);
                    cmd.Parameters.AddWithValue("@crn", nutri.Crn);
                    cmd.Parameters.AddWithValue("@nome", nutri.Nome);
                    cmd.Parameters.AddWithValue("@senha", nutri.senha);

                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    cn.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public void Apagar(Nutricionista nutri)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                try {
                    cn.Open();

                    StringBuilder sb = new StringBuilder();
                    sb.Append("DELETE                       ");
                    sb.Append("  FROM tblNutricionista      ");
                    sb.Append(" WHERE id_nutri = @id_nutri  ");

                    SqlCommand cmd = new SqlCommand(sb.ToString(), cn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@id_nutri", nutri.Id_Nutri);
                
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    cn.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public Nutricionista BuscarPorId(int id)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                try {
                    cn.Open();

                    StringBuilder sb = new StringBuilder();
                    sb.Append("SELECT id_nutri, crn, nome, senha    ");
                    sb.Append("  FROM tblNutricionista              ");
                    sb.Append(" WHERE id_nutri = @id_nutri          ");

                    SqlCommand cmd = new SqlCommand(sb.ToString(), cn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@id_nutri", id);

                    SqlDataReader dr = cmd.ExecuteReader();

                    Nutricionista nutri = new Nutricionista();

                    if (dr.Read())
                    {
                        nutri.Id_Nutri = int.Parse(dr["id_nutri"].ToString());
                        nutri.Crn = dr["crn"].ToString();
                        nutri.Nome = dr["nome"].ToString();
                        nutri.senha = dr["senha"].ToString();
                    }

                    cmd.Dispose();
                    cn.Close();

                    return nutri;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public Nutricionista BuscarPorNome(string nome)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                try {
                    cn.Open();

                    StringBuilder sb = new StringBuilder();
                    sb.Append("SELECT id_nutri, crn, nome, senha    ");
                    sb.Append("  FROM tblNutricionista              ");
                    sb.Append(" WHERE nome = @nome                  ");

                    SqlCommand cmd = new SqlCommand(sb.ToString(), cn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@nome", nome);

                    SqlDataReader dr = cmd.ExecuteReader();

                    Nutricionista nutri = new Nutricionista();

                    if (dr.Read())
                    {
                        nutri.Id_Nutri = int.Parse(dr["id_nutri"].ToString());
                        nutri.Crn = dr["crn"].ToString();
                        nutri.Nome = dr["nome"].ToString();
                        nutri.senha = dr["senha"].ToString();
                    }

                    cmd.Dispose();
                    cn.Close();

                    return nutri;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public Nutricionista Logar(string nome, string senha)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                try {
                    cn.Open();

                    StringBuilder sb = new StringBuilder();
                    sb.Append("SELECT id_nutri, crn, nome, senha    ");
                    sb.Append("  FROM tblNutricionista              ");
                    sb.Append("  WHERE nome = @nome                 ");
                    sb.Append("   AND senha = @senha                ");

                    SqlCommand cmd = new SqlCommand(sb.ToString(), cn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@nome", nome);
                    cmd.Parameters.AddWithValue("@senha", senha);

                    SqlDataReader dr = cmd.ExecuteReader();

                    Nutricionista nutri = null;

                    if (dr.Read())
                    {
                        nutri = new Nutricionista();
                        nutri.Id_Nutri = int.Parse(dr["id_nutri"].ToString());
                        nutri.Crn = dr["crn"].ToString();
                        nutri.Nome = dr["nome"].ToString();
                        nutri.senha = dr["senha"].ToString();
                    }

                    cmd.Dispose();
                    cn.Close();

                    return nutri;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}