﻿using Dieta.ClassesBasicas;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieta.DAO
{
    class NutricionistaDAO2
    {
        public void Gravar(Nutricionista nutri)
        {
            using (var context = new Contexto())
            {
                try
                {
                    context.Nutricionistas.Add(nutri);
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public void Atualizar(Nutricionista nutri)
        {
            using (var context = new Contexto())
            {
                try
                {
                    Nutricionista nut = context.Nutricionistas.SingleOrDefault(n => n.Id_Nutri == nutri.Id_Nutri);
                    nut.Crn = nutri.Crn;
                    nut.Nome = nutri.Nome;
                    nut.senha = nutri.senha;

                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public void Apagar(Nutricionista nutri)
        {
            using (var context = new Contexto())
            {
                try
                {
                    context.Nutricionistas.Remove(nutri);
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public Nutricionista BuscarPorId(int id)
        {
            using (var context = new Contexto())
            {
                try
                {
                    return context.Nutricionistas.Where(n => n.Id_Nutri == id).FirstOrDefault();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public Nutricionista BuscarPorNome(string nome)
        {
            using (var context = new Contexto())
            {
                try
                {
                    return context.Nutricionistas.Where(n => n.Nome.Equals(nome)).FirstOrDefault();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public Nutricionista Logar(string nome, string senha)
        {
            using (var context = new Contexto())
            {
                try
                {
                    var x = context.Nutricionistas.Where(n => n.Nome == nome && n.senha == senha);
                    return x.FirstOrDefault();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}
