namespace Dieta
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using Dieta.ClassesBasicas;

    public partial class Contexto : DbContext
    {
        public Contexto()
            : base("name=Contexto")
        {
        }

        public virtual DbSet<Consulta> Consultas { get; set; }
        public virtual DbSet<Nutricionista> Nutricionistas { get; set; }
        public virtual DbSet<Paciente> Pacientes { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Consulta>()
                .Property(e => e.PESO)
                .HasPrecision(18, 0);

            modelBuilder.Entity<Consulta>()
                .Property(e => e.ALTURA)
                .HasPrecision(18, 0);

            modelBuilder.Entity<Consulta>()
                .Property(e => e.IMC)
                .HasPrecision(4, 2);

            modelBuilder.Entity<Consulta>()
                .Property(e => e.OBSERVACOES)
                .IsUnicode(false);

            modelBuilder.Entity<Nutricionista>()
                .Property(e => e.Crn)
                .IsUnicode(false);

            modelBuilder.Entity<Nutricionista>()
                .Property(e => e.Nome)
                .IsUnicode(false);

            modelBuilder.Entity<Nutricionista>()
                .Property(e => e.senha)
                .IsUnicode(false);

            modelBuilder.Entity<Nutricionista>()
                .HasMany(e => e.Consultas)
                .WithRequired(e => e.Nutricionista)
                .HasForeignKey(e => e.ID_NUTRI_CONSULTA)
                .WillCascadeOnDelete(false);
            
            modelBuilder.Entity<Nutricionista>()
                .HasMany(e => e.Pacientes)
                .WithRequired(e => e.Nutricionista)
                .HasForeignKey(e => e.ID_NUTRI_PACIENTE)
                .WillCascadeOnDelete(false);
                
            modelBuilder.Entity<Paciente>()
                .Property(e => e.NOME)
                .IsUnicode(false);

            modelBuilder.Entity<Paciente>()
                .Property(e => e.TELEFONE)
                .IsUnicode(false);

            modelBuilder.Entity<Paciente>()
                .HasMany(e => e.Consultas)
                .WithRequired(e => e.Paciente)
                .HasForeignKey(e => e.ID_PACIENTE_CONSULTA)
                .WillCascadeOnDelete(false);
                
        }
    }
}
