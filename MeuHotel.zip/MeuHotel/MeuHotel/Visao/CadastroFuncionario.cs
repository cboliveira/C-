﻿using MeuHotel.Visao;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Validation;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MeuHotel
{
    public partial class CadastroFuncionario : Form
    {
        public CadastroFuncionario()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

            HotelEntities hotel = new HotelEntities();
            Funcionario funcionario = new Funcionario();

            funcionario.NOME = textBoxNomeFuncionario.Text;
            funcionario.FUNCAO = textBoxFuncaoFuncionario.Text;
            funcionario.CPF = textBoxCpfFuncionario.Text;
            funcionario.SALARIO = Convert.ToDecimal(textBoxSalarioFuncionario.Text);
            funcionario.ENDERECO = textBoxEnderecoFuncionario.Text;
            funcionario.TELEFONE = textBoxTelefoneFuncionario.Text;
            funcionario.EMAIL = textBoxEmailFuncionario.Text;
            funcionario.IDADE = Convert.ToInt32(textBoxIdadeFuncionario.Text);
            funcionario.SITUACAO = textBoxSituacaoFuncionario.Text;
            funcionario.SENHA = textBoxSenhaFuncionario.Text;

            hotel.Funcionario.Add(funcionario);
            hotel.SaveChanges();

            MessageBox.Show("Cadastro concluído com sucesso!");


         
        }

        private void VoltarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoginADM login = new LoginADM();
            login.Show();
            this.Hide();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            TelaInicialADM login = new TelaInicialADM();
            login.Show();
            this.Hide();
        }
    }
}
