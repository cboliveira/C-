﻿namespace MeuHotel
{
    partial class CadastroFuncionario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxIdadeFuncionario = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxEmailFuncionario = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxTelefoneFuncionario = new System.Windows.Forms.TextBox();
            this.textBoxEnderecoFuncionario = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBoxSituacaoFuncionario = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxSalarioFuncionario = new System.Windows.Forms.TextBox();
            this.textBoxFuncaoFuncionario = new System.Windows.Forms.TextBox();
            this.textBoxCpfFuncionario = new System.Windows.Forms.TextBox();
            this.textBoxNomeFuncionario = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.voltarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxSenhaFuncionario = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(133, 431);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 23);
            this.button2.TabIndex = 23;
            this.button2.Text = "Voltar para Menu";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(296, 431);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 23);
            this.button1.TabIndex = 29;
            this.button1.Text = "Concluir cadastro";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // textBoxIdadeFuncionario
            // 
            this.textBoxIdadeFuncionario.Location = new System.Drawing.Point(154, 383);
            this.textBoxIdadeFuncionario.Name = "textBoxIdadeFuncionario";
            this.textBoxIdadeFuncionario.Size = new System.Drawing.Size(122, 20);
            this.textBoxIdadeFuncionario.TabIndex = 28;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(82, 386);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 15);
            this.label10.TabIndex = 27;
            this.label10.Text = "Idade :";
            // 
            // textBoxEmailFuncionario
            // 
            this.textBoxEmailFuncionario.Location = new System.Drawing.Point(154, 352);
            this.textBoxEmailFuncionario.Name = "textBoxEmailFuncionario";
            this.textBoxEmailFuncionario.Size = new System.Drawing.Size(122, 20);
            this.textBoxEmailFuncionario.TabIndex = 26;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(82, 352);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 15);
            this.label9.TabIndex = 25;
            this.label9.Text = "Email :";
            // 
            // textBoxTelefoneFuncionario
            // 
            this.textBoxTelefoneFuncionario.Location = new System.Drawing.Point(154, 318);
            this.textBoxTelefoneFuncionario.Name = "textBoxTelefoneFuncionario";
            this.textBoxTelefoneFuncionario.Size = new System.Drawing.Size(122, 20);
            this.textBoxTelefoneFuncionario.TabIndex = 24;
            // 
            // textBoxEnderecoFuncionario
            // 
            this.textBoxEnderecoFuncionario.Location = new System.Drawing.Point(154, 283);
            this.textBoxEnderecoFuncionario.Name = "textBoxEnderecoFuncionario";
            this.textBoxEnderecoFuncionario.Size = new System.Drawing.Size(209, 20);
            this.textBoxEnderecoFuncionario.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(35, 247);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 17);
            this.label8.TabIndex = 21;
            this.label8.Text = "Complementos :";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.textBoxSenhaFuncionario);
            this.panel1.Controls.Add(this.textBoxSituacaoFuncionario);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.textBoxSalarioFuncionario);
            this.panel1.Controls.Add(this.textBoxFuncaoFuncionario);
            this.panel1.Controls.Add(this.textBoxCpfFuncionario);
            this.panel1.Controls.Add(this.textBoxNomeFuncionario);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(35, 76);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(453, 156);
            this.panel1.TabIndex = 20;
            // 
            // textBoxSituacaoFuncionario
            // 
            this.textBoxSituacaoFuncionario.Location = new System.Drawing.Point(84, 112);
            this.textBoxSituacaoFuncionario.Name = "textBoxSituacaoFuncionario";
            this.textBoxSituacaoFuncionario.Size = new System.Drawing.Size(100, 20);
            this.textBoxSituacaoFuncionario.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(14, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 15);
            this.label12.TabIndex = 8;
            this.label12.Text = "Situação :";
            // 
            // textBoxSalarioFuncionario
            // 
            this.textBoxSalarioFuncionario.Location = new System.Drawing.Point(318, 68);
            this.textBoxSalarioFuncionario.Name = "textBoxSalarioFuncionario";
            this.textBoxSalarioFuncionario.Size = new System.Drawing.Size(100, 20);
            this.textBoxSalarioFuncionario.TabIndex = 7;
            // 
            // textBoxFuncaoFuncionario
            // 
            this.textBoxFuncaoFuncionario.Location = new System.Drawing.Point(318, 27);
            this.textBoxFuncaoFuncionario.Name = "textBoxFuncaoFuncionario";
            this.textBoxFuncaoFuncionario.Size = new System.Drawing.Size(122, 20);
            this.textBoxFuncaoFuncionario.TabIndex = 6;
            // 
            // textBoxCpfFuncionario
            // 
            this.textBoxCpfFuncionario.Location = new System.Drawing.Point(84, 68);
            this.textBoxCpfFuncionario.Name = "textBoxCpfFuncionario";
            this.textBoxCpfFuncionario.Size = new System.Drawing.Size(123, 20);
            this.textBoxCpfFuncionario.TabIndex = 5;
            // 
            // textBoxNomeFuncionario
            // 
            this.textBoxNomeFuncionario.Location = new System.Drawing.Point(84, 27);
            this.textBoxNomeFuncionario.Name = "textBoxNomeFuncionario";
            this.textBoxNomeFuncionario.Size = new System.Drawing.Size(157, 20);
            this.textBoxNomeFuncionario.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "CPF :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(258, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Salário :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(258, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Função :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(179, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(179, 18);
            this.label7.TabIndex = 19;
            this.label7.Text = "Cadastro de Funcionários";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(82, 318);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 15);
            this.label6.TabIndex = 18;
            this.label6.Text = "Telefone :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(82, 283);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 15);
            this.label5.TabIndex = 17;
            this.label5.Text = "Endereço :";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.voltarToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(527, 24);
            this.menuStrip1.TabIndex = 30;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // voltarToolStripMenuItem
            // 
            this.voltarToolStripMenuItem.Name = "voltarToolStripMenuItem";
            this.voltarToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.voltarToolStripMenuItem.Text = "Voltar";
            this.voltarToolStripMenuItem.Click += new System.EventHandler(this.VoltarToolStripMenuItem_Click);
            // 
            // textBoxSenhaFuncionario
            // 
            this.textBoxSenhaFuncionario.Location = new System.Drawing.Point(318, 112);
            this.textBoxSenhaFuncionario.Name = "textBoxSenhaFuncionario";
            this.textBoxSenhaFuncionario.Size = new System.Drawing.Size(100, 20);
            this.textBoxSenhaFuncionario.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(258, 112);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 15);
            this.label11.TabIndex = 11;
            this.label11.Text = "Senha :";
            // 
            // CadastroFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 485);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxIdadeFuncionario);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBoxEmailFuncionario);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxTelefoneFuncionario);
            this.Controls.Add(this.textBoxEnderecoFuncionario);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "CadastroFuncionario";
            this.Text = "Cadastro Funcionarios";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxIdadeFuncionario;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxEmailFuncionario;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxTelefoneFuncionario;
        private System.Windows.Forms.TextBox textBoxEnderecoFuncionario;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxSituacaoFuncionario;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxSalarioFuncionario;
        private System.Windows.Forms.TextBox textBoxFuncaoFuncionario;
        private System.Windows.Forms.TextBox textBoxCpfFuncionario;
        private System.Windows.Forms.TextBox textBoxNomeFuncionario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem voltarToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxSenhaFuncionario;
        private System.Windows.Forms.Label label11;
    }
}

