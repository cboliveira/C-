﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MeuHotel.Visao
{
    public partial class Receitas_Hospedes : Form
    {
        public Receitas_Hospedes()
        {
            InitializeComponent();
        }

        private void VoltarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaInicialADM tela = new TelaInicialADM();
            tela.Show();
            this.Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            HotelEntities hotelEntities = new HotelEntities();
            Cliente cliente = new Cliente();
            Quarto quarto = new Quarto();

            cliente.ID_QUARTO_CLIENTE = quarto.ID_QUARTO;
            cliente.NOME = textBoxNomeCliente.Text;
            cliente.CPF = textBoxCpfCliente.Text;
            cliente.TELEFONE = textBoxTelefoneCliente.Text;
            cliente.QTD_PESSOAS = Convert.ToInt32(numericUpDownQtdPessoas.Value);
            cliente.DIAS = Convert.ToInt32(numericUpDownQTDdias.Value);

            quarto.TIPO = textBoxTipoQuarto.Text;
            quarto.ANDAR = Convert.ToInt32(textBoxAndarQuarto.Text);
            quarto.NUMERO = Convert.ToInt32(textBoxNumeroQuarto.Text);
            quarto.QTD_BANHEIRO = Convert.ToInt32(numericUpDownBanheiroQuarto.Value);
            quarto.QTD_CAMA = Convert.ToInt32(numericUpDownCamaQuarto.Value);

            hotelEntities.Cliente.Add(cliente);
            hotelEntities.Quarto.Add(quarto);
            hotelEntities.SaveChanges();

            MessageBox.Show("Cliente Cadastrado com Sucesso!");

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            TelaInicialADM telaInicialADM = new TelaInicialADM();
            telaInicialADM.Show();
            this.Close();
        }
    }
}
