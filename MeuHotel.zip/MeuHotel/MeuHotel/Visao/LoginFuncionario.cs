﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MeuHotel.Visao
{
    public partial class LoginFuncionario : Form
    {
        public LoginFuncionario()
        {
            InitializeComponent();
        }

        private void AdministradorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoginADM login = new LoginADM();
            login.Show();
            this.Hide();
        }
    }
}
