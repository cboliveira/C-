﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MeuHotel.Classe;

namespace MeuHotel.Visao
{
    public partial class LoginADM : Form
    {
        public LoginADM()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if ((textBoxLoginNome.Text == "") || (textBoxLoginSenha.Text == ""))
            {
                MessageBox.Show("Informe nome de usuário e senha!");
                textBoxLoginNome.Focus();
            }

            Metodos logar = new Metodos();
            Funcionario funcionario = logar.LogarADM(textBoxLoginNome.Text, textBoxLoginSenha.Text);

            if (funcionario != null)
            {
                TelaInicialADM tela = new TelaInicialADM();
                tela.Show();
                this.Hide();
            }

            else
            {
                MessageBox.Show("Usuário e senha incorretos!");
                textBoxLoginNome.Focus();
            }






        }

        private void FuncionárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoginFuncionario login = new LoginFuncionario();
            login.Show();
            this.Close();
        }
    }
}
