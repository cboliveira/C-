﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeuHotel.Classe
{
   public class Metodos
    {
        public Funcionario LogarADM(string cpf, string senha)
        {
            using (var context = new HotelEntities())
            {
                try
                {
                    var x = context.Funcionario.Where(f => cpf == "12345678910" && f.SENHA == "begostoso");
                    return x.FirstOrDefault();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}
